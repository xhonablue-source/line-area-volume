# Mr. H Math Worksheet Library

A small Streamlit app that lists all the Mr. H Math worksheets in one place, with
short descriptions, Common Core and Michigan K-12 standard tags, and a download
button for each PDF.

## How to run it

1. Make sure you have Python installed.
2. Open a terminal in this folder (the one with `app.py`).
3. Install the one dependency:

   ```
   pip install -r requirements.txt
   ```

4. Start the app:

   ```
   streamlit run app.py
   ```

5. Your browser will open automatically to a local page (usually
   `http://localhost:8501`) showing the worksheet library.

## Folder structure

```
streamlit_app/
├── app.py              <- the app itself
├── requirements.txt
├── README.md
└── assets/
    ├── jelly_bean_fractions_worksheet.pdf
    ├── tuesday_times_tables_speed_sheet.pdf
    ├── factor_tree_frenzy.pdf
    ├── read_it_solve_it_fractions.pdf
    ├── improper_to_mixed.pdf
    ├── survey_says_fractions.pdf
    ├── multiplying_fractions_survey.pdf
    ├── dividing_fractions_survey.pdf
    ├── line_area_volume_growth.pdf
    └── math_word_craft_guessword.pdf
```

To add a new worksheet later: drop the PDF into `assets/`, then add a matching
entry to the `WORKSHEETS` list near the top of `app.py` (title, description,
topic, CCSS code(s), Michigan code(s), and the filename).
